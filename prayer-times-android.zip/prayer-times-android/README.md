# مواقيت الصلاة — Ahmed Eid

تطبيق مواقيت صلاة بتصميم Liquid Glass على خلفية AMOLED، فيه تذكيرات وصوت أذان وسبحة.

## 1) ملف الأذان
حط ملف الأذان (mp3) باسم **adhan.mp3** جوه فولدر `www/` (جنب index.html).
- في المتصفح: بيتشغّل من الصفحة.
- في الأندرويد: السكربت بينسخه لـ `res/raw` وبيبقى صوت إشعار الأذان.
لو الملف مش موجود، التطبيق بيشتغل بنغمة بسيطة بدل الأذان.

## 2) بناء APK من غير كمبيوتر (GitHub Actions)
1. ارفع المشروع كله على مستودع GitHub جديد.
2. من تاب Actions شغّل Build APK (أو هيشتغل لوحده مع أول push).
3. بعد ما يخلص، نزّل `prayer-times-apk` من Artifacts وفكّ الضغط وثبّت app-debug.apk.

## 3) بناء APK على كمبيوتر
محتاج Node 20 و JDK 17 و Android SDK:

    npm install
    bash scripts/prepare-android.sh
    cd android && ./gradlew assembleDebug

الملف بيطلع في: `android/app/build/outputs/apk/debug/app-debug.apk`
(أو افتح فولدر android في Android Studio.)

## ملاحظات مهمة للتنبيهات
- وافق على صلاحية الإشعارات، ومن زرار "تفعيل التنبيهات" وافق على "المنبهات والتذكيرات" (أندرويد 12+).
- ابعد التطبيق عن توفير البطارية (Battery optimization → Unrestricted)، وإلا بعض الأجهزة بتأخر التنبيهات.
- التنبيهات بتتجدول ٧ أيام قدّام، فافتح التطبيق مرة في الأسبوع على الأقل.
