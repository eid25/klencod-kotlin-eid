#!/usr/bin/env bash
# يجهّز مشروع الأندرويد: يضيف المنصة + الصلاحيات + ملف صوت الأذان ثم يعمل sync
set -e
[ -d android ] || npx cap add android

MAN=android/app/src/main/AndroidManifest.xml
add_perm() {
  grep -q "$1" "$MAN" || sed -i "s#<application#<uses-permission android:name=\"$1\" />\n    <application#" "$MAN"
}
add_perm android.permission.POST_NOTIFICATIONS
add_perm android.permission.SCHEDULE_EXACT_ALARM
add_perm android.permission.VIBRATE
add_perm android.permission.RECEIVE_BOOT_COMPLETED

RAW=android/app/src/main/res/raw
mkdir -p "$RAW"
if [ -f www/adhan.mp3 ]; then
  cp www/adhan.mp3 "$RAW/adhan.mp3"
else
  echo "تنبيه: مفيش www/adhan.mp3 - الإشعارات هتشتغل بصوت النظام الافتراضي بدل الأذان."
fi

npx cap sync android
echo "تمام. افتح android في Android Studio أو شغّل: cd android && ./gradlew assembleDebug"
